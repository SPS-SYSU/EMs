import pandas as pd
import numpy as np
import math as mt
import torch
import random
from sklearn.model_selection import train_test_split
import torch.nn.functional as F
import torch.utils.data as Data
from sklearn.decomposition import PCA
import os
import matplotlib.pyplot as plt
from sklearn.model_selection import KFold
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import StratifiedKFold

class Net(torch.nn.Module):
    def __init__(self, n_feature,n_output, n_hidden=40):
        super(Net, self).__init__()
        self.hidden1 = torch.nn.Linear(n_feature, n_hidden)  # hidden layer
        self.hidden2 = torch.nn.Linear(n_hidden, n_hidden)
        #self.hidden3 = torch.nn.Linear(n_hidden, n_hidden)
        self.out = torch.nn.Linear(n_hidden, n_output)  # output layer

    def forward(self, x):
        x = torch.relu(self.hidden1(x))      # activation function for hidden layer
        #print('!!!!!!!!')
        x = torch.relu(self.hidden2(x))
        #x = torch.relu(self.hidden3(x))
        #print('!!!!!!!!')
        x = self.out(x)
        return x
def load_data(String1,String2):
    fr = open(String1)  ###这个位置你们要成电脑中相应文件的位置
    df = pd.DataFrame(pd.read_csv(fr,header=None))
    fr1 = open(String2)
    df1 = pd.DataFrame(pd.read_csv(fr1, header=None))
    ans_1 = df.iloc[:, 0]  # 第一列参考答案
    test_1 = df1.iloc[:, 0]
    data_1 = df.iloc[:, 2:]  # 对应第一列答案的数据集
    test_data_1 = df1.iloc[:, 2:]
    merge_ans1_data1 = pd.concat([ans_1, data_1], axis=1).dropna(axis=0,
                                                                 how='any')  ##合并分子式，第一列参考答案，以及相应的数据集#并删除掉含有Nan的行
    merge_ans2_data2 = pd.concat([test_1, test_data_1], axis=1).dropna(axis=0,
                                                                       how='any')


    Y_1 = np.mat(merge_ans1_data1.iloc[:, 0])
    Y_2 = np.mat(merge_ans2_data2.iloc[:, 0])
    X_1 = np.mat(merge_ans1_data1.iloc[:, 1:])
    X_2 = np.mat(merge_ans2_data2.iloc[:, 1:])
    X_1_min = np.mat(X_1.min(0))
    X_1_max = np.mat(X_1.max(0))
    fenmu_1 = np.tile(X_1_max - X_1_min, (np.shape(X_1)[0], 1))
    fenmu_2 = np.tile(X_1_max - X_1_min, (np.shape(X_2)[0], 1))
    Y_1_revised = []
    for i in range(np.shape(Y_1)[1]):
        Y_1_revised.append(float(Y_1[0, i]))
    Y_1_revised = [0 if i > 2.6 else 1 for i in Y_1_revised]
    Y_2_revised = []
    for i in range(np.shape(Y_2)[1]):
        Y_2_revised.append(float(Y_2[0, i]))
    Y_2_revised = [0 if i > 2.6 else 1 for i in Y_2_revised]
    X_1_revised = np.multiply(X_1 - X_1_min, 1 / fenmu_1)
    X_2_revised = np.multiply(X_2 - X_1_min, 1 / fenmu_2)
    #print(np.shape(X_1_revised))
    Pca = PCA(n_components=109).fit(X_1_revised)
    #print(np.shape(Pca))
    x_final = Pca.transform(X_1_revised)
    #print(np.shape(x_final))
    #print("**********")
    test_final = Pca.transform(X_2_revised)
    # print(np.sum(y_train))
    fr.close()
    fr1.close()
    print(np.shape(x_final),np.shape(test_final))
    #return X_1_revised, X_2_revised, Y_1_revised, Y_2_revised

    return x_final,test_final,Y_1_revised,Y_2_revised

if __name__ == '__main__':
    ans = []
    String1 = "E:/brandy/Neural Network(SYSU)/2020/20191116data.csv"
    String2 = "E:/brandy/Neural Network(SYSU)/2020/validation.csv"
    max = 0
    max_index = []
    dataset, testset, labelset, testlabel = load_data(String1, String2)
    accuracy_total = []
    device = torch.device(
        'cuda:{}'.format(0) if torch.cuda.is_available() and 0 != -1 else 'cpu')
    x = torch.FloatTensor(dataset).to(device)  # ##转换数据类型，这是pytorch要求的数据类型
    x1 = torch.FloatTensor(testset).to(device)
    y = torch.LongTensor(labelset).to(device)
    y1 = torch.LongTensor(testlabel).to(device)
    best_accuracy = 0.0
    while True:
        net = Net(n_feature=np.shape(dataset)[1], n_output=2).to(device)
        optimizer = torch.optim.SGD(net.parameters(), lr=0.0012, momentum=0.8)  # ##Adam是类似梯度下降的一种优化方法，lr是学习率
        loss_func = torch.nn.CrossEntropyLoss()  # 损失函数选择交叉熵函数

        for t in range(60000):  # 训练次数
            net.train()
            out = net(x)  # input x and predict based on x
            loss = loss_func(out,
                             y)  # must be (1. nn output, 2. target), the target label is NOT one-hotted

            optimizer.zero_grad()  # clear gradients for next train
            loss.backward()  # backpropagation, compute gradients
            optimizer.step()  # apply gradients
            # print(loss)

            prediction = torch.max(out, 1)[1]

            if t % 2000 == 0:
                net.eval()
                out = net(x1)
                a = torch.max(out, 1)
                prediction = torch.max(out, 1)[1]
                pred_y = prediction.data.cpu().numpy()
                print(pred_y)
                target_y = y1.data.cpu().numpy()
                print(target_y)
                abc = float((pred_y == target_y).astype(int).sum()) / float(target_y.size)
                print(abc)
                if abc > 0.88:
                    best_accuracy = abc
                    best_model = net
                    break
                print('now best accuracy:%.5f' % abc)
        if best_accuracy > 0.9:
            break
    torch.save(best_model, 'E:\model_best_new2.pkl')


