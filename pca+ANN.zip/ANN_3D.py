import torch
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import os
from mpl_toolkits.mplot3d import Axes3D
path = "E:\\ANN_3D_dataSet\\"
file = os.listdir(path)
pca_dimensions = []
hidden_neurons = []
accuracy = []
for i in os.listdir(path):
    fr = open("E:\\50_150\\" + i)
    neurons = i.split(' ')[-1].split('.')[0]
    df = pd.DataFrame(pd.read_csv(fr))
    for p,a in zip(df.iloc[:, 1], df.iloc[:,2]):# 第一列参考答案
        if a < 84:
            continue
        pca_dimensions.append(p)
        accuracy.append(a)
        hidden_neurons.append(int(neurons))
ax = plt.subplot(111, projection='3d')
print(np.shape(hidden_neurons))
print(np.shape(accuracy))
print(hidden_neurons)
for index in range(np.shape(accuracy)[0]):
    '''if pca_dimensions[index] < 0.7 or C[index] > 1.0:
        continue
    if gamma[index] < 0.1 or gamma[index] > 0.3:
        continue
    if accuracy[index] <= 85.713:

        ax.scatter(C[index], gamma[index], accuracy[index], c='y')
    else:
        print(accuracy[index])
        ax.scatter(C[index], gamma[index], accuracy[index], s=30, alpha=1, c='r')
    '''
    if accuracy[index] > 87:
        print(accuracy[index])
        ax.scatter(pca_dimensions[index], hidden_neurons[index], accuracy[index], s=30, alpha=1, c='r')
    else:

        ax.scatter(pca_dimensions[index], hidden_neurons[index], accuracy[index], s=30, alpha=1, c='y')

font1 = {'family': 'Times New Roman',
         'weight': 'normal',
         'size': 16,
         }
ax.set_xlabel('Pca dimensions', font1)
ax.set_ylabel("Hidden neurons", font1)
ax.set_zlabel("Accuracy", font1)

x_major_locator = plt.MultipleLocator(20)
# 把x轴的刻度间隔设置为1，并存在变量里
y_major_locator = plt.MultipleLocator(40)
# 把y轴的刻度间隔设置为10，并存在变量里
ax.xaxis.set_major_locator(x_major_locator)
ax.yaxis.set_major_locator(y_major_locator)
ax.set_ylim(20, 200)

plt.show()