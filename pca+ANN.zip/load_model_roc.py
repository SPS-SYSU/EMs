import pandas as pd
import numpy as np
import math as mt
import torch
import random
from sklearn.model_selection import train_test_split
import torch.nn.functional as F
import torch.utils.data as Data
from sklearn.decomposition import PCA
import os
import matplotlib.pyplot as plt
from sklearn.model_selection import KFold
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import StratifiedKFold
from torch import nn

class Net(torch.nn.Module):
    def __init__(self, n_feature=109,n_output=2, n_hidden=40):
        super(Net, self).__init__()
        self.hidden1 = torch.nn.Linear(n_feature, n_hidden)  # hidden layer
        self.hidden2 = torch.nn.Linear(n_hidden, n_hidden)
        #self.hidden3 = torch.nn.Linear(n_hidden, n_hidden)
        self.out = torch.nn.Linear(n_hidden, n_output)  # output layer

    def forward(self, x):
        x = torch.relu(self.hidden1(x))      # activation function for hidden layer
        #print('!!!!!!!!')
        x = torch.relu(self.hidden2(x))
        #x = torch.relu(self.hidden3(x))
        #print('!!!!!!!!')
        x = self.out(x)
        return x


def load_dataSet_1(p, iter):  ###p，pca维度，iter，从均分为十份的数据中提取出当前第i份的数据做测试集，剩下的9份做训练集
    fr = open("F:/pca/20191116data.csv")  ###这个位置你们要成电脑中相应文件的位置
    # "E:/20191022_220.csv"
    df = pd.DataFrame(pd.read_csv(fr, header=None))
    print(np.shape(df))
    ans_1 = df.iloc[:, 0]  # 第一列参考答案
    data_1 = df.iloc[:, 2:]  # 对应第一列答案的数据集
    merge_ans1_data1 = pd.concat([ans_1, data_1], axis=1).dropna(axis=0,
                                                                 how='any')
    Y_1 = np.mat(merge_ans1_data1.iloc[:, 0])
    X_1 = np.mat(merge_ans1_data1.iloc[:, 1:])
    X_1_min = np.mat(X_1.min(0))
    X_1_max = np.mat(X_1.max(0))
    fenmu_1 = np.tile(X_1_max - X_1_min, (np.shape(X_1)[0], 1))
    Y_1_revised = []
    for i in range(np.shape(Y_1)[1]):
        Y_1_revised.append(float(Y_1[0, i]))
    Y_1_revised = [0 if i > 2.6 else 1 for i in Y_1_revised]

    X_1_revised = np.multiply(X_1 - X_1_min, 1 / fenmu_1)
    Pca = PCA(n_components=p).fit(X_1_revised)
    x_final = Pca.transform(X_1_revised)
    # y_final = Pca.transform(X_2_revised)
    kf = KFold(n_splits=10, shuffle=True, random_state=10)  # 均分为十份
    count = 0  # 作为标记，判断当前是拿拿一份数据做测试集
    for (x_train_index, x_test_index) in (kf.split(x_final)):
        count += 1
        if count == iter:
            break
    count = 0
    for (y_train_index, y_test_index) in (kf.split(Y_1_revised)):
        count += 1
        if count == iter:
            break
    print()
    fr.close()
    x_train = x_final[x_train_index]
    x_test = x_final[x_test_index]
    y_train = [Y_1_revised[i] for i in y_train_index]
    y_test = [Y_1_revised[i] for i in y_test_index]
    print(np.shape(x_train), np.shape(y_train))
    return x_train, x_test, y_train, y_test

if __name__ == '__main__':
    ans = []
    String1 = "F:/pca/20191116data.csv"
    String2 = "F:/pca/validation.csv"
    max = 0
    torch.manual_seed(0)
    print(torch.rand(2))
    max_index= []
    total_accuracy = 0
    Score_Max = 0
    mean_tpr = 0.0  # 用来记录画平均ROC曲线的信息
    mean_fpr = np.linspace(0, 1, 100)
    Score_total = []
    temp = []
    roc_area = []
    for i in range(1, 11):
        torch.manual_seed(0)
        print(torch.rand(2))
        dataset, testset, labelset, testlabel = load_dataSet_1(109, i)
        accuracy_total = []
        x = torch.FloatTensor(dataset)  # ##转换数据类型，这是pytorch要求的数据类型
        x1 = torch.FloatTensor(testset)
        y = torch.LongTensor(labelset)
        y1 = torch.LongTensor(testlabel)
        net = torch.load('F:\pca\sub_best_model'+str(i)+'.pkl')
        loss_func = torch.nn.CrossEntropyLoss()  # 损失函数选择交叉熵函数
        net.eval()
        out = net(x1)
        proba = F.softmax(out, dim=1)
        prediction = torch.max(out, 1)[1]
        pred_y = prediction.data.numpy()

        target_y = y1.data.numpy()
        score = float((pred_y == target_y).astype(int).sum()) / float(target_y.size)
        total_accuracy += score
        print(score)
        print(np.shape(proba.detach().numpy()[:,1]))
        print(np.shape(testlabel))
        fpr, tpr, thresholds = roc_curve(testlabel, proba.detach().numpy()[:,1])
        mean_tpr += np.interp(mean_fpr, fpr, tpr)  # 插值函数 interp(x坐标,每次x增加距离,y坐标)  累计每次循环的总值后面求平均值
        mean_tpr[0] = 0  # 将第一个真正例=0 以0为起点

        roc_auc = auc(fpr, tpr)  # 求auc面积
        roc_area.append(roc_auc)
        if score >= Score_Max:
            fpr_max = fpr
            tpr_max = tpr
            roc_auc_best = roc_auc
            Score_Max = score
        temp.append(score)
        print(score)
    ans.append(temp)
    print(roc_area)
    print(f"std:{np.std(roc_area)}")



    print(total_accuracy)
    plt.plot([0, 1], [0, 1], '--', color=(0.6, 0.6, 0.6))
    mean_tpr /= 10  # 求数组的平均值
    mean_tpr[-1] = 1.0  # 坐标最后一个点为（1,1）  以1为终点
    mean_auc = auc(mean_fpr, mean_tpr)
    plt.plot(fpr_max, tpr_max, 'r',lw=1, label='Best ROC (area = {0:.2f})'.format(roc_auc_best))  # 画出当前分割数据的ROC曲线

    plt.plot(mean_fpr, mean_tpr, 'k--', label='Mean ROC (area = {0:.2f})'.format(mean_auc), lw=2)

    # plt.plot(mean_fpr, mean_tpr, 'k--', label='Mean ROC (area = {0:.2f})'.format(mean_auc), lw=2)

    plt.xlim([-0.05, 1.05])  # 设置x、y轴的上下限，设置宽一点，以免和边缘重合，可以更好的观察图像的整体
    plt.ylim([-0.05, 1.05])
    plt.xlabel('False positive rate')
    plt.ylabel('True positive rate')  # 可以使用中文，但需要导入一些库即字体
    # plt.title('Receiver operating characteristic example')
    plt.legend(loc="lower right")
    plt.show()