import pandas as pd
import numpy as np
import math as mt
import torch
import random
from sklearn.model_selection import train_test_split
import torch.nn.functional as F
import torch.utils.data as Data
from sklearn.decomposition import PCA
import os
import matplotlib.pyplot as plt
from sklearn.model_selection import KFold
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import StratifiedKFold
from torch import nn
class Net(torch.nn.Module):
    def __init__(self, n_feature=109,n_output=2, n_hidden=40):
        super(Net, self).__init__()
        self.hidden1 = torch.nn.Linear(n_feature, n_hidden)  # hidden layer
        self.hidden2 = torch.nn.Linear(n_hidden, n_hidden)
        #self.hidden3 = torch.nn.Linear(n_hidden, n_hidden)
        self.out = torch.nn.Linear(n_hidden, n_output)  # output layer

    def forward(self, x):
        x = torch.relu(self.hidden1(x))      # activation function for hidden layer
        #print('!!!!!!!!')
        x = torch.relu(self.hidden2(x))
        #x = torch.relu(self.hidden3(x))
        #print('!!!!!!!!')
        x = self.out(x)
        return x

def load_dataSet_1(p,iter):###p，pca维度，iter，从均分为十份的数据中提取出当前第i份的数据做测试集，剩下的9份做训练集
    fr = open("E:/brandy/Neural Network(SYSU)/2020/20191116data.csv") ###这个位置你们要成电脑中相应文件的位置
    #"E:/20191022_220.csv"
    df = pd.DataFrame(pd.read_csv(fr,header=None))
    df = df
    ans_1 = df.iloc[:, 0]  # 第一列参考答案
    data_1 = df.iloc[:, 2:]  # 对应第一列答案的数据集
    merge_ans1_data1 = pd.concat([ans_1, data_1], axis=1).dropna(axis=0,
                                                                 how='any')
    Y_1 = np.mat(merge_ans1_data1.iloc[:, 0])
    X_1 = np.mat(merge_ans1_data1.iloc[:, 1:])
    X_1_min = np.mat(X_1.min(0))
    X_1_max = np.mat(X_1.max(0))
    fenmu_1 = np.tile(X_1_max - X_1_min, (np.shape(X_1)[0], 1))
    Y_1_revised = []
    for i in range(np.shape(Y_1)[1]):
        Y_1_revised.append(float(Y_1[0, i]))
    Y_1_revised = [0 if i > 2.6 else 1 for i in Y_1_revised]

    X_1_revised = np.multiply(X_1 - X_1_min, 1 / fenmu_1)
    '''x_zhou = np.arange(0,220)
    X_zero = [i for (i,v) in enumerate(Y_1_revised) if v==0]
    X_one = [i for (i,v) in enumerate(Y_1_revised) if v==1]
    X_data_one=[X_1_revised[i] for i in X_one];X_data_zero = [X_1_revised[i] for i in X_zero]
    X_one_sum = np.mean(X_data_one,axis = 0).T
    X_zero_sum = np.mean(X_data_zero,axis = 0).T
    X_one_sum = pd.DataFrame(X_one_sum)
    X_zero_sum = pd.DataFrame(X_zero_sum)
    X_zero_sum.to_csv("E:\Compare.csv")
    X_one_sum.to_csv("E:\Compare1.csv")
    print(X_one_sum)
    X_temp0 = [i for i in X_one_sum[0]];X_temp1 =[i for i in X_zero_sum[0]]
    plt.plot(x_zhou,X_temp0,'r',label = 'one')
    plt.plot(x_zhou,X_temp1,'b',label = 'zero')
    plt.legend()
    plt.show()'''
    Pca = PCA(n_components=p).fit(X_1_revised)
    x_final = Pca.transform(X_1_revised)
    # y_final = Pca.transform(X_2_revised)
    kf = KFold(n_splits=10, shuffle=True, random_state=10)  #均分为十份
    count = 0  #作为标记，判断当前是拿拿一份数据做测试集
    for (x_train_index, x_test_index) in (kf.split(x_final)):
        count += 1
        if count == iter:
            break
    count = 0
    for (y_train_index, y_test_index) in (kf.split(Y_1_revised)):
        count += 1
        if count == iter:
            break
    print(x_test_index)
    fr.close()
    x_train = x_final[x_train_index]
    x_test = x_final[x_test_index]
    y_train = [Y_1_revised[i] for i in y_train_index]
    y_test = [Y_1_revised[i] for i in y_test_index]
    print(np.shape(x_train), np.shape(y_train))
    return x_train, x_test, y_train, y_test
def cal_accuracy(TP,TN,FP,FN):
    return (len(TP) + len(TN)) / (len(TP) + len(FN)+len(TN) + len(FP))
def cal_sensivity(TP, FN):
    return len(TP)/(len(TP) + len(FN))
def cal_spec(TN, FP):
    return len(TN)/(len(TN) + len(FP))
def cal_PPV(TP, FP):
    return len(TP)/(len(TP) + len(FP))
def cal_NPV(TN, FN):
    return len(TN)/(len(TN) + len(FN))
if __name__ == "__main__":

    total_result = []
    column_name = ['predict', 'test_truth']
    Hstack = ['StandardDeviation', 'Mean']

    for i in range(1, 11):
        Hstack.append(str(i))
    print(Hstack)
    for Iter in range(5):
        total_result = []
        accuracy_total = 0.0
        for j in range(1, 11):
            torch.manual_seed(0)
            dataset, testset, labelset, testlabel = load_dataSet_1(109, j)
            x = torch.FloatTensor(dataset)  # ##转换数据类型，这是pytorch要求的数据类型
            x1 = torch.FloatTensor(testset)
            y = torch.LongTensor(labelset)
            y1 = torch.LongTensor(testlabel)
            net_all_data = torch.load('E:\sub_best_model'+str(j)+'.pkl')
            net_all_data.eval()
            out = net_all_data(x1)
            prediction = torch.max(out, 1)[1]
            pred_y = prediction.data.numpy()
            target_y = y1.data.numpy()
            #print(float((pred_y == target_y).astype(int).sum()))

            abc = float((pred_y == target_y).astype(int).sum()) / float(target_y.size)
            print(f"第{j}次 {abc}")
            target_y = np.array(testlabel)
            print(type(accuracy_total),type(abc))
            accuracy_total += 10*abc
            pred_y = pred_y
            testlabel = testlabel
            record_wrong = [r for r in range(target_y.size) if (pred_y == target_y).astype(int)[r] == 0]
            record_right = [r for r in range(target_y.size) if (pred_y == target_y).astype(int)[r] == 1]

            FP = [z for z in record_wrong if target_y[z] == 0]#0判断成1
            FN = [z for z in record_wrong if target_y[z] == 1]#1判断成0
            TP = [z for z in record_right if target_y[z] == 1]#1判断成1
            TN = [z for z in record_right if target_y[z] == 0]#0判断成0
            ALL_CAL_RESUTLT = [abc, cal_sensivity(TP, FN),cal_spec(TN, FP),cal_PPV(TP, FP),cal_NPV(TN, FN)]

            total_result.append(ALL_CAL_RESUTLT[Iter])
            print(len(FP) + len(FN) + len(TP) + len(TN))
        print(len(target_y))
        print(accuracy_total)
        new_result = []
        new_result.append(np.std(total_result))
        new_result.append(np.mean(total_result))
        for i in total_result:

            new_result.append(i)
        #print(new_result)
        #print(total_result)
        #print(np.mean(total_result))
        #print(np.std(total_result))
        #print(len(new_result))
        pd.DataFrame(data=np.mat(new_result), columns=Hstack).to_csv(
            "E:\\ANN_十倍交叉验证指标2.csv", mode='a')