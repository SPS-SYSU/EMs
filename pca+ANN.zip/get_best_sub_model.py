import pandas as pd
import numpy as np
import math as mt
import torch
import random
from sklearn.model_selection import train_test_split
import torch.nn.functional as F
import torch.utils.data as Data
from sklearn.decomposition import PCA
import os
import matplotlib.pyplot as plt
from sklearn.model_selection import KFold
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import StratifiedKFold
from torch import nn

class Net(torch.nn.Module):
    def __init__(self, n_feature, n_hidden, n_output):
        super(Net, self).__init__()
        self.hidden1 = torch.nn.Linear(n_feature, n_hidden)  # hidden layer
        self.hidden2 = torch.nn.Linear(n_hidden, n_hidden)
        # self.hidden3 = torch.nn.Linear(n_hidden, n_hidden)
        self.out = torch.nn.Linear(n_hidden, n_output)  # output layer

    def forward(self, x):
        x = torch.relu(self.hidden1(x))  # activation function for hidden layer
        x = torch.relu(self.hidden2(x))
        x = self.out(x)
        return x


def load_dataSet_1(p, iter):  ###p，pca维度，iter，从均分为十份的数据中提取出当前第i份的数据做测试集，剩下的9份做训练集
    fr = open("E:/brandy/Neural Network(SYSU)/2020/20191116data.csv")  ###这个位置你们要成电脑中相应文件的位置
    # "E:/20191022_220.csv"
    df = pd.DataFrame(pd.read_csv(fr, header=None))
    print(np.shape(df))
    ans_1 = df.iloc[:, 0]  # 第一列参考答案
    data_1 = df.iloc[:, 2:]  # 对应第一列答案的数据集
    merge_ans1_data1 = pd.concat([ans_1, data_1], axis=1).dropna(axis=0,
                                                                 how='any')
    Y_1 = np.mat(merge_ans1_data1.iloc[:, 0])
    X_1 = np.mat(merge_ans1_data1.iloc[:, 1:])
    X_1_min = np.mat(X_1.min(0))
    X_1_max = np.mat(X_1.max(0))
    fenmu_1 = np.tile(X_1_max - X_1_min, (np.shape(X_1)[0], 1))
    Y_1_revised = []
    for i in range(np.shape(Y_1)[1]):
        Y_1_revised.append(float(Y_1[0, i]))
    Y_1_revised = [0 if i > 2.6 else 1 for i in Y_1_revised]

    X_1_revised = np.multiply(X_1 - X_1_min, 1 / fenmu_1)
    Pca = PCA(n_components=p).fit(X_1_revised)
    x_final = Pca.transform(X_1_revised)
    # y_final = Pca.transform(X_2_revised)
    kf = KFold(n_splits=10, shuffle=True, random_state=10)  # 均分为十份
    count = 0  # 作为标记，判断当前是拿拿一份数据做测试集
    for (x_train_index, x_test_index) in (kf.split(x_final)):
        count += 1
        if count == iter:
            break
    count = 0
    for (y_train_index, y_test_index) in (kf.split(Y_1_revised)):
        count += 1
        if count == iter:
            break
    print()
    fr.close()
    x_train = x_final[x_train_index]
    x_test = x_final[x_test_index]
    y_train = [Y_1_revised[i] for i in y_train_index]
    y_test = [Y_1_revised[i] for i in y_test_index]
    print(np.shape(x_train), np.shape(y_train))
    return x_train, x_test, y_train, y_test


if __name__ == "__main__":
    Accuracy = []
    num = 200
    Step = 1  ##代表步长
    Init_num = 150  # ## 这里代表PCA起始维度
    accuracy_total = 0.0
    for i in range(1, 11):
        Accuracy_total = 0
        best_score =0.0
        for j in range(10):
            dataset, testset, labelset, testlabel = load_dataSet_1(109, i)

            x = torch.FloatTensor(dataset)  # ##转换数据类型，这是pytorch要求的数据类型
            x1 = torch.FloatTensor(testset)
            y = torch.LongTensor(labelset)
            y1 = torch.LongTensor(testlabel)

            net = Net(n_feature=109, n_hidden=40, n_output=2)  # 定义神经网络，F是神经元个数，在神经网络定义中，我定义了各层的神经元数量都是F

            optimizer = torch.optim.SGD(net.parameters(), lr=0.0012, momentum=0.8)  # ##Adam是类似梯度下降的一种优化方法，lr是学习率
            loss_func = torch.nn.CrossEntropyLoss()  # 损失函数选择交叉熵函数

            for t in range(60000):  # 训练次数
                out = net(x)  # input x and predict based on x
                loss = loss_func(out,
                                 y)  # must be (1. nn output, 2. target), the target label is NOT one-hotted

                optimizer.zero_grad()  # clear gradients for next train
                loss.backward()  # backpropagation, compute gradients
                optimizer.step()  # apply gradients
                # print(loss)
                prediction = torch.max(out, 1)[1]
                pred_y = prediction.data.numpy()
                target_y = y.data.numpy()
                accuracy = float((pred_y == target_y).astype(int).sum()) / float(target_y.size)
            print("样本准确率%.2f" % accuracy)
            out = net(x1)
            a = torch.max(out, 1)
            prediction = torch.max(out, 1)[1]
            pred_y = prediction.data.numpy()
            print(pred_y)
            target_y = y1.data.numpy()
            print(target_y)
            abc = float((pred_y == target_y).astype(int).sum()) / float(target_y.size)
            print('accuracy:%.5f   ' % (abc))
            if best_score <= abc:
                best_score = abc
                print(f"now score{best_score}")
                best_model = net
        accuracy_total += 10*best_score
        print(accuracy_total)
        torch.save(best_model, 'E:\sub_best_model' + str(i) + '.pkl')


