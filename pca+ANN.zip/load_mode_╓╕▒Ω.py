import pandas as pd
import numpy as np
import math as mt
import torch
import random
from sklearn.model_selection import train_test_split
import torch.nn.functional as F
import torch.utils.data as Data
from sklearn.decomposition import PCA
import os
import matplotlib.pyplot as plt
from sklearn.model_selection import KFold
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import StratifiedKFold

class Net(torch.nn.Module):
    def __init__(self, n_feature=109,n_output=2, n_hidden=40):
        super(Net, self).__init__()
        self.hidden1 = torch.nn.Linear(n_feature, n_hidden)  # hidden layer
        self.hidden2 = torch.nn.Linear(n_hidden, n_hidden)
        #self.hidden3 = torch.nn.Linear(n_hidden, n_hidden)
        self.out = torch.nn.Linear(n_hidden, n_output)  # output layer

    def forward(self, x):
        x = torch.relu(self.hidden1(x))      # activation function for hidden layer
        #print('!!!!!!!!')
        x = torch.relu(self.hidden2(x))
        #x = torch.relu(self.hidden3(x))
        #print('!!!!!!!!')
        x = self.out(x)
        return x
def load_data(String1,String2):
    fr = open(String1)  ###这个位置你们要成电脑中相应文件的位置
    df = pd.DataFrame(pd.read_csv(fr,header=None))
    fr1 = open(String2)
    df1 = pd.DataFrame(pd.read_csv(fr1, header=None))
    ans_1 = df.iloc[:, 0]  # 第一列参考答案
    test_1 = df1.iloc[:, 0]
    data_1 = df.iloc[:, 2:]  # 对应第一列答案的数据集
    test_data_1 = df1.iloc[:, 2:]
    merge_ans1_data1 = pd.concat([ans_1, data_1], axis=1).dropna(axis=0,
                                                                 how='any')  ##合并分子式，第一列参考答案，以及相应的数据集#并删除掉含有Nan的行
    merge_ans2_data2 = pd.concat([test_1, test_data_1], axis=1).dropna(axis=0,
                                                                       how='any')


    Y_1 = np.mat(merge_ans1_data1.iloc[:, 0])
    Y_2 = np.mat(merge_ans2_data2.iloc[:, 0])
    X_1 = np.mat(merge_ans1_data1.iloc[:, 1:])
    X_2 = np.mat(merge_ans2_data2.iloc[:, 1:])
    X_1_min = np.mat(X_1.min(0))
    X_1_max = np.mat(X_1.max(0))
    fenmu_1 = np.tile(X_1_max - X_1_min, (np.shape(X_1)[0], 1))
    fenmu_2 = np.tile(X_1_max - X_1_min, (np.shape(X_2)[0], 1))
    Y_1_revised = []
    for i in range(np.shape(Y_1)[1]):
        Y_1_revised.append(float(Y_1[0, i]))
    Y_1_revised = [0 if i > 2.6 else 1 for i in Y_1_revised]
    Y_2_revised = []
    for i in range(np.shape(Y_2)[1]):
        Y_2_revised.append(float(Y_2[0, i]))
    Y_2_revised = [0 if i > 2.6 else 1 for i in Y_2_revised]
    X_1_revised = np.multiply(X_1 - X_1_min, 1 / fenmu_1)
    X_2_revised = np.multiply(X_2 - X_1_min, 1 / fenmu_2)
    #print(np.shape(X_1_revised))
    Pca = PCA(n_components=109).fit(X_1_revised)
    # print(np.shape(Pca))
    x_final = Pca.transform(X_1_revised)
    # print(np.shape(x_final))
    # print("**********")
    test_final = Pca.transform(X_2_revised)
    # print(np.sum(y_train))
    fr.close()
    fr1.close()
    print(np.shape(x_final), np.shape(test_final))
    # return X_1_revised, X_2_revised, Y_1_revised, Y_2_revised

    return x_final, test_final, Y_1_revised, Y_2_revised
def cal_accuracy(TP,TN,FP,FN):
    return (len(TP) + len(TN)) / (len(TP) + len(FN)+len(TN) + len(FP))
def cal_sensivity(TP, FN):
    return len(TP)/(len(TP) + len(FN))
def cal_spec(TN, FP):
    return len(TN)/(len(TN) + len(FP))
def cal_PPV(TP, FP):
    return len(TP)/(len(TP) + len(FP))
def cal_NPV(TN, FN):
    return len(TN)/(len(TN) + len(FN))
if __name__ == '__main__':
    ans = []
    String1 = "E:/brandy/Neural Network(SYSU)/2020/20191116data.csv"
    String2 = "E:/brandy/Neural Network(SYSU)/2020/validation.csv"
    max = 0
    max_index= []
    dataset, testset, labelset, testlabel = load_data(String1,String2)
    accuracy_total = []
    x = torch.FloatTensor(dataset)  # ##转换数据类型，这是pytorch要求的数据类型
    x1 = torch.FloatTensor(testset)
    y = torch.LongTensor(labelset)
    y1 = torch.LongTensor(testlabel)
    net = torch.load('E:\model_best_new1.pkl')
    loss_func = torch.nn.CrossEntropyLoss()  # 损失函数选择交叉熵函数


    out = net(x1)

    loss = loss_func(out,y1)

    a = torch.max(out, 1)
    prediction = torch.max(out, 1)[1]
    pred_y = prediction.data.numpy()

    score = torch.matmul(y1,prediction)

    print(f"score={score}")
    print(torch.max(out, 1)[0])
    target_y = y1.data.numpy()
    print(target_y)
    abc = float((pred_y == target_y).astype(int).sum()) / float(target_y.size)
    column_name = ['predict', 'test_truth']
    row_name = ['accuracy', 'sensivity', 'spec', 'ppv', 'npv']
    pd.DataFrame(data=np.hstack((np.mat(pred_y).T, np.mat(target_y).T)), columns=column_name).to_csv(
        "E:/ANN_具体数据.csv")
    record_wrong = [r for r in range(target_y.size) if (pred_y == target_y).astype(int)[r] == 0]
    record_right = [r for r in range(target_y.size) if (pred_y == target_y).astype(int)[r] == 1]
    FP = [z for z in record_wrong if target_y[z] == 0]  # 0判断成1
    FN = [z for z in record_wrong if target_y[z] == 1]  # 1判断成0
    TP = [z for z in record_right if target_y[z] == 1]  # 1判断成1
    TN = [z for z in record_right if target_y[z] == 0]  # 0判断成0
    ALL_CAL_RESUTLT = [cal_accuracy(TP, TN, FP, FN), cal_sensivity(TP, FN), cal_spec(TN, FP), cal_PPV(TP, FP),
                       cal_NPV(TN, FN)]
    accuracy_total.append(abc)
    print('accuracy:%.5f' %abc)
    pd.DataFrame(data=np.mat(ALL_CAL_RESUTLT), columns=row_name).to_csv(
        "E:/ANN_预测指标.csv")


