import pandas as pd
import numpy as np
import math as mt
import torch
import random
from sklearn.model_selection import train_test_split
import torch.nn.functional as F
from sklearn.preprocessing import StandardScaler
from sklearn import svm
from sklearn.model_selection import GridSearchCV, train_test_split
import torch.utils.data as Data
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import KFold
from sklearn.model_selection import StratifiedKFold
def load_dataSet_1(iter):###这个是载入第一列输出和相应输入的数据，
    fr = open("F:/pca/20191116data.csv")  ###这个位置你们要成电脑中相应文件的位置

    df = pd.DataFrame(pd.read_csv(fr,header=None))
    ans_1 = df.iloc[:, 0]  # 第一列参考答案

    data_1 = df.iloc[:, 2:]  # 对应第一列答案的数据集

    merge_ans1_data1 = pd.concat([ans_1, data_1], axis=1).dropna(axis=0,
                                                                 how='any')  ##合并分子式，第一列参考答案，以及相应的数据集#并删除掉含有Nan的行

    Y_1 = np.mat(merge_ans1_data1.iloc[:, 0])
    X_1 = np.mat(merge_ans1_data1.iloc[:, 1:])
    X_1_min = np.mat(X_1.min(0))
    X_1_max = np.mat(X_1.max(0))
    fenmu_1 = np.tile(X_1_max - X_1_min, (np.shape(X_1)[0], 1))
    Y_1_revised = []
    for i in range(np.shape(Y_1)[1]):
        Y_1_revised.append(float(Y_1[0, i]))
    Y_1_revised = [0 if i > 2.6 else 1 for i in Y_1_revised]

    X_1_revised = np.multiply(X_1 - X_1_min, 1 / fenmu_1)


    Pca = PCA(n_components=44).fit(X_1_revised)
    x_final = Pca.transform(X_1_revised)

    kf = KFold(n_splits=10,shuffle=True,random_state=10)#均分为十份
    count = 0#作为标记，判断当前是拿拿一份数据做测试集
    for (x_train_index,x_test_index) in (kf.split(x_final)):
        count +=1
        if count == iter:
            break
    count = 0
    for (y_train_index,y_test_index) in (kf.split(Y_1_revised)):
        count +=1
        if count == iter:
            break

    fr.close()
    x_train = x_final[x_train_index]
    x_test = x_final[x_test_index]
    y_train = [Y_1_revised[i] for i in y_train_index]
    y_test = [Y_1_revised[i] for i in y_test_index]
    return x_train, x_test, y_train, y_test
def svm_c(c,gamma,x_train, x_test, y_train, y_test):
    # rbf核函数，设置数据权重
    #print(np.shape(x_train))
    svc = svm.SVC(kernel='rbf',C = c,gamma=gamma,probability=True)
    #c_range = 0.8993401455163021#np.logspace(-2.5, 0,base=2)
    #gamma_range = 0.3767910847028079#np.logspace(-2, -1, base=2)
    # 网格搜索交叉验证的参数范围，cv=3,3折交叉
    #param_grid = [{'kernel': ['rbf'], 'C': c_range, 'gamma': gamma_range}]
    #grid = GridSearchCV(svc, param_grid, cv=10, n_jobs=-1)
    # 训练模型
    grid = svc
    grid.fit(x_train, y_train)
    # 计算测试集精度

    #print("训练精度%s" % grid.score(x_train,y_train))
    #print(y_test)
    #print(grid.predict(x_test))
    score = grid.score(x_test, y_test)
    #print(np.shape(y_test),np.sum(y_test))
    proba= grid.predict_proba(x_test)
    #print(y_test)
    #print(grid.predict(x_test))
    #print(proba)
    #print('精度为%s' % score)
    return score,proba[:,1],y_test




if __name__ == '__main__':
    ans = []
    total_ans = 0
    C = [1.0]  #
    gamma = [0.27891447944038594]
    Score_Max = 0
    mean_tpr = 0.0  # 用来记录画平均ROC曲线的信息
    mean_fpr = np.linspace(0, 1, 100)
    Score_total = []
    roc_area = []
    for (z,i) in zip(gamma,C) :

        temp = []
        for j in range(1, 11):
            score,proba,y_test = svm_c(i, z, *load_dataSet_1(j))
            print(score)
            Score_total.append(score)
            print(proba)
            print(np.shape(proba))
            fpr,tpr,thresholds = roc_curve(y_test,proba)

            mean_tpr += np.interp(mean_fpr, fpr, tpr)  # 插值函数 interp(x坐标,每次x增加距离,y坐标)  累计每次循环的总值后面求平均值
            mean_tpr[0]=0  # 将第一个真正例=0 以0为起点

            roc_auc = auc(fpr, tpr)  # 求auc面积
            roc_area.append(roc_auc)
            #plt.plot(fpr, tpr, lw=1, label='ROC fold {0:.2f} (AUC = {1:.2f})'.format(j, roc_auc))  # 画出当前分割数据的ROC曲线
            if score  >= Score_Max:
                fpr_max = fpr
                tpr_max = tpr
                roc_auc_best = roc_auc
                Score_Max = score
            temp.append(score)
        ans.append(temp)
        # print(total_ans)
    print(roc_area)
    print("std:{}".format(np.std(roc_area)))
    plt.plot([0, 1], [0, 1], '--', color=(0.6, 0.6, 0.6))
    mean_tpr /= j  # 求数组的平均值
    mean_tpr[-1] = 1.0  # 坐标最后一个点为（1,1）  以1为终点
    mean_auc = auc(mean_fpr, mean_tpr)
    plt.plot(fpr_max, tpr_max, 'r',lw=1, label='Best ROC (area = {0:.2f})'.format(roc_auc_best))  # 画出当前分割数据的ROC曲线

    plt.plot(mean_fpr, mean_tpr, 'k--', label='Mean ROC (area = {0:.2f})'.format(mean_auc), lw=2)

    plt.xlim([-0.05, 1.05])  # 设置x、y轴的上下限，设置宽一点，以免和边缘重合，可以更好的观察图像的整体
    plt.ylim([-0.05, 1.05])
    plt.xlabel('False positive rate')
    plt.ylabel('True positive rate')  # 可以使用中文，但需要导入一些库即字体
    plt.legend(loc="lower right")
    plt.show()
    go = []
    for i in ans:
        #print(i)
        #print(np.sum(i)/10)
        go.append(np.mean(i))
    #print(np.argsort(go)[::-1])
    #print(np.max(go))
    #print(C)
    #print(gamma)
