import pandas as pd
import numpy as np
import math as mt
import matplotlib.pyplot as plt
from sklearn import svm
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.decomposition import PCA
from sklearn.model_selection import KFold
def load_data(String1,String2,P):
    fr = open(String1)  ###这个位置你们要成电脑中相应文件的位置
    df = pd.DataFrame(pd.read_csv(fr,header=None))
    fr1 = open(String2)
    df1 = pd.DataFrame(pd.read_csv(fr1, header=None))
    ans_1 = df.iloc[:, 0]  # 第一列参考答案
    test_1 = df1.iloc[:, 0]
    data_1 = df.iloc[:, 2:]  # 对应第一列答案的数据集
    test_data_1 = df1.iloc[:, 2:]
    merge_ans1_data1 = pd.concat([ans_1, data_1], axis=1).dropna(axis=0,
                                                                 how='any')  ##合并分子式，第一列参考答案，以及相应的数据集#并删除掉含有Nan的行
    merge_ans2_data2 = pd.concat([test_1, test_data_1], axis=1).dropna(axis=0,
                                                                       how='any')


    Y_1 = np.mat(merge_ans1_data1.iloc[:, 0])
    Y_2 = np.mat(merge_ans2_data2.iloc[:, 0])
    X_1 = np.mat(merge_ans1_data1.iloc[:, 1:])
    X_2 = np.mat(merge_ans2_data2.iloc[:, 1:])
    X_1_min = np.mat(X_1.min(0))
    X_1_max = np.mat(X_1.max(0))
    fenmu_1 = np.tile(X_1_max - X_1_min, (np.shape(X_1)[0], 1))
    fenmu_2 = np.tile(X_1_max - X_1_min, (np.shape(X_2)[0], 1))
    Y_1_revised = []
    for i in range(np.shape(Y_1)[1]):
        Y_1_revised.append(float(Y_1[0, i]))
    Y_1_revised = [0 if i > 2.6 else 1 for i in Y_1_revised]
    Y_2_revised = []
    for i in range(np.shape(Y_2)[1]):
        Y_2_revised.append(float(Y_2[0, i]))
    Y_2_revised = [0 if i > 2.6 else 1 for i in Y_2_revised]
    X_1_revised = np.multiply(X_1 - X_1_min, 1 / fenmu_1)
    X_2_revised = np.multiply(X_2 - X_1_min, 1 / fenmu_2)
    #print(np.shape(X_1_revised))
    print(P)
    Pca = PCA(n_components=P).fit(X_1_revised)
    #print(np.shape(Pca))
    x_final = Pca.transform(X_1_revised)
    #print(np.shape(x_final))
    #print("**********")
    test_final = Pca.transform(X_2_revised)
    # print(np.sum(y_train))
    fr.close()
    fr1.close()
    print(np.shape(x_final),np.shape(test_final))
    #return X_1_revised, X_2_revised, Y_1_revised, Y_2_revised

    return x_final,test_final,Y_1_revised,Y_2_revised

def load_dataSet_1(p,iter):###这个是载入第一列输出和相应输入的数据，
    fr = open("F:/data/20191116data.csv")  ###这个位置你们要成电脑中相应文件的位置
    df = pd.DataFrame(pd.read_csv(fr,header=None))

    ans_1 = df.iloc[:, 0]  # 第一列参考答案
    data_1 = df.iloc[:, 2:]  # 对应第一列答案的数据集
    merge_ans1_data1 = pd.concat([ans_1, data_1], axis=1).dropna(axis=0,
                                                                 how='any')  ##合并分子式，第一列参考答案，以及相应的数据集#并删除掉含有Nan的行

    Y_1 = np.mat(merge_ans1_data1.iloc[:, 0])

    X_1 = np.mat(merge_ans1_data1.iloc[:, 1:])

    X_1_min = np.mat(X_1.min(0))
    X_1_max = np.mat(X_1.max(0))
    fenmu_1 = np.tile(X_1_max - X_1_min, (np.shape(X_1)[0], 1))

    Y_1_revised = []
    for i in range(np.shape(Y_1)[1]):
        Y_1_revised.append(float(Y_1[0, i]))
    Y_1_revised = [0 if i > 2.6 else 1 for i in Y_1_revised]
    X_1_revised = np.multiply(X_1 - X_1_min, 1 / fenmu_1)

    Pca = PCA(n_components=p).fit(X_1_revised)
    x_final = Pca.transform(X_1_revised)
    #y_final = Pca.transform(X_2_revised)
    kf = KFold(n_splits=10,shuffle=True,random_state=10)#均分为十份
    count = 0#作为标记，判断当前是拿拿一份数据做测试集
    for (x_train_index,x_test_index) in (kf.split(x_final)):
        count +=1
        if count == iter:
            break
    count = 0
    for (y_train_index,y_test_index) in (kf.split(Y_1_revised)):
        count +=1
        if count == iter:
            break

    #x_train, x_test, y_train, y_test = train_test_split(x_final, Y_1_revised, test_size=0.2,random_state=iter)

    fr.close()
    x_train = x_final[x_train_index]
    x_test = x_final[x_test_index]
    y_train = [Y_1_revised[i] for i in y_train_index]
    y_test = [Y_1_revised[i] for i in y_test_index]
    return x_train, x_test, y_train, y_test
def svm_c(x_train, x_test, y_train, y_test,C,G):
    # rbf核函数，设置数据权重
    #print(np.shape(x_train))
    svc = svm.SVC(kernel='rbf',)
    C_range = [C]
    gamma_range = [G]
    # 网格搜索交叉验证的参数范围，cv=3,3折交叉
    param_grid = [{'kernel': ['rbf'], 'C': C_range, 'gamma': gamma_range}]
    grid = GridSearchCV(svc, param_grid, cv=10, n_jobs=-1)
    # 训练模型

    clf = grid.fit(x_train, y_train)
    # 计算测试集精度

    #print("训练精度%s" % grid.score(x_train,y_train))
    #print(y_test)
    ##print(clf.predict(x_test))
    score = grid.score(x_test, y_test)
    #print('精度为%s' % score)
    return score,clf.best_params_,clf.best_score_



if __name__ == '__main__':

    String1 = "F:/data/20191116data.csv"
    String2 = "F:/data/validation.csv"
    C_range =[1.0]#np.logspace(-2, 1 ,20, base=2) #
    total_max_score = []
    gamma_range =[0.27891447944038594]#np.logspace(-3, -1,20, base=2) # np.logspace(-4, 2, 30, base=2)# #
    test_total_score = []
    for p in range(1,221):
        C = []
        gamma = []
        mean_S = []
        for c in C_range:
            for g in gamma_range:
                S = []
                gamma.append(g)
                C.append(c)
                for j in range(1, 11):
                    score, para, score1 = svm_c(*load_dataSet_1(p, j),c,g)

                    S.append(score)
                mean_S.append(np.mean(S))
                score_test, para_test, score1_test = svm_c(*load_data(String1, String2,p), c, g)
                test_total_score.append(score_test)
        socre_Index = np.argsort(mean_S)[::-1]
        C_temp = []
        gamma_temp = []
        mean_S_temp = []
        test_score_to_file = []
        for i in socre_Index:
            C_temp.append(C[i])
            gamma_temp.append((gamma[i]))
            mean_S_temp.append(mean_S[i])
            test_score_to_file.append(test_total_score[i])
        total_max_score.append(np.max(mean_S))
        C = np.mat(C_temp).T
        gamma = np.mat(gamma_temp).T
        mean_S = np.mat(mean_S_temp).T
        test_score_to_file = np.mat(test_score_to_file).T
        total  = np.hstack((C,gamma,mean_S,test_score_to_file))
        name = ['C','gamma','Score','predict']
        print(np.max(mean_S_temp))
        test = pd.DataFrame(columns=name, data=total)

        test.to_csv('E:\\svm_score'+str(p)+'.csv', index=False)
    plt.plot(total_max_score)
    plt.xlabel("K dimensions")
    plt.ylabel("Accuracy")
    plt.show()
    print(np.argsort(total_max_score))
    plt.show()








    '''
    for j in range(1,11):

        score,para,score1 = svm_c(*load_dataSet_1(100,j))
        ans.append(score)
        C.append(para["C"])
        gamma.append(para["gamma"])
        S.append(score1)
    print(S)
    print(ans)
    print(np.mean(ans))
    print(C)
    print(gamma)
    print(np.min(C),np.max(C))
    print(np.min(gamma),np.max(gamma))

    print(1)'''