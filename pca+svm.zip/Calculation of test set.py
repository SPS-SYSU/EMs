import pandas as pd
import numpy as np
import math as mt
import torch
import random
from sklearn.model_selection import train_test_split
import torch.nn.functional as F
from sklearn.preprocessing import StandardScaler
from sklearn import svm
from sklearn.model_selection import GridSearchCV, train_test_split
import torch.utils.data as Data
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import KFold
from sklearn.model_selection import StratifiedKFold
def load_dataSet_1(iter):###这个是载入第一列输出和相应输入的数据，
    fr = open("F:/data/20191116data.csv")  ###这个位置你们要成电脑中相应文件的位置
    #"E:/20191022_220.csv"
    df = pd.DataFrame(pd.read_csv(fr,header=None))

    ans_1 = df.iloc[:, 0]  # 第一列参考答案
    data_1 = df.iloc[:, 2:]  # 对应第一列答案的数据集
    merge_ans1_data1 = pd.concat([ans_1, data_1], axis=1).dropna(axis=0,
                                                                 how='any')  ##合并分子式，第一列参考答案，以及相应的数据集#并删除掉含有Nan的行
    Y_1 = np.mat(merge_ans1_data1.iloc[:, 0])
    X_1 = np.mat(merge_ans1_data1.iloc[:, 1:])
    X_1_min = np.mat(X_1.min(0))
    X_1_max = np.mat(X_1.max(0))
    fenmu_1 = np.tile(X_1_max - X_1_min, (np.shape(X_1)[0], 1))
    Y_1_revised = []
    for i in range(np.shape(Y_1)[1]):
        Y_1_revised.append(float(Y_1[0, i]))
    Y_1_revised = [0 if i > 2.6 else 1 for i in Y_1_revised]
    X_1_revised = np.multiply(X_1 - X_1_min, 1 / fenmu_1)

    Pca = PCA(n_components=70).fit(X_1_revised)
    x_final = Pca.transform(X_1_revised)
    kf = KFold(n_splits=10,shuffle=True,random_state=10)#均分为十份
    count = 0#作为标记，判断当前是拿拿一份数据做测试集
    for (x_train_index,x_test_index) in (kf.split(x_final)):
        count +=1
        if count == iter:
            break
    count = 0
    for (y_train_index,y_test_index) in (kf.split(Y_1_revised)):
        count +=1
        if count == iter:
            break

    fr.close()
    x_train = x_final[x_train_index]
    x_test = x_final[x_test_index]
    y_train = [Y_1_revised[i] for i in y_train_index]
    y_test = [Y_1_revised[i] for i in y_test_index]
    return x_train, x_test, y_train, y_test
def load_data(String1,String2,P):
    fr = open(String1)  ###这个位置你们要成电脑中相应文件的位置
    df = pd.DataFrame(pd.read_csv(fr,header=None))
    fr1 = open(String2)
    df1 = pd.DataFrame(pd.read_csv(fr1, header=None))
    ans_1 = df.iloc[:, 0]  # 第一列参考答案
    test_1 = df1.iloc[:, 0]
    data_1 = df.iloc[:, 2:]  # 对应第一列答案的数据集
    test_data_1 = df1.iloc[:, 2:]
    merge_ans1_data1 = pd.concat([ans_1, data_1], axis=1).dropna(axis=0,
                                                                 how='any')  ##合并分子式，第一列参考答案，以及相应的数据集#并删除掉含有Nan的行
    merge_ans2_data2 = pd.concat([test_1, test_data_1], axis=1).dropna(axis=0,
                                                                       how='any')


    Y_1 = np.mat(merge_ans1_data1.iloc[:, 0])
    Y_2 = np.mat(merge_ans2_data2.iloc[:, 0])
    X_1 = np.mat(merge_ans1_data1.iloc[:, 1:])
    X_2 = np.mat(merge_ans2_data2.iloc[:, 1:])
    X_1_min = np.mat(X_1.min(0))
    X_1_max = np.mat(X_1.max(0))
    fenmu_1 = np.tile(X_1_max - X_1_min, (np.shape(X_1)[0], 1))
    fenmu_2 = np.tile(X_1_max - X_1_min, (np.shape(X_2)[0], 1))
    Y_1_revised = []
    for i in range(np.shape(Y_1)[1]):
        Y_1_revised.append(float(Y_1[0, i]))
    Y_1_revised = [0 if i > 2.6 else 1 for i in Y_1_revised]
    Y_2_revised = []
    for i in range(np.shape(Y_2)[1]):
        Y_2_revised.append(float(Y_2[0, i]))
    Y_2_revised = [0 if i > 2.6 else 1 for i in Y_2_revised]
    X_1_revised = np.multiply(X_1 - X_1_min, 1 / fenmu_1)
    X_2_revised = np.multiply(X_2 - X_1_min, 1 / fenmu_2)
    #print(np.shape(X_1_revised))
    #print(P)
    Pca = PCA(n_components=P).fit(X_1_revised)
    #print(np.shape(Pca))
    x_final = Pca.transform(X_1_revised)
    #print(np.shape(x_final))
    #print("**********")
    test_final = Pca.transform(X_2_revised)
    # print(np.sum(y_train))
    fr.close()
    fr1.close()
    #print(np.shape(x_final),np.shape(test_final))
    #return X_1_revised, X_2_revised, Y_1_revised, Y_2_revised

    return x_final,test_final,Y_1_revised,Y_2_revised
def svm_c(x_train, x_test, y_train, y_test):
    # rbf核函数，设置数据权重
    #print(np.shape(x_train))

    #svc = svm.LinearSVC(C=3)
    svc = svm.SVC(kernel='rbf', C=1.0

                  , gamma=0.27891447944038594, probability=True)
    #c_range = 0.8993401455163021#np.logspace(-2.5, 0,base=2)
    #gamma_range = 0.3767910847028079#np.logspace(-2, -1, base=2)
    # 网格搜索交叉验证的参数范围，cv=3,3折交叉
    #param_grid = [{'kernel': ['rbf'], 'C': c_range, 'gamma': gamma_range}]
    #grid = GridSearchCV(svc, param_grid, cv=10, n_jobs=-1)
    # 训练模型
    grid = svc
    grid.fit(x_train, y_train)
    # 计算测试集精度
    #print("训练精度%s" % grid.score(x_train,y_train))
    #print(y_test)
    #print(grid.predict(x_test))
    score = grid.score(x_test, y_test)
    #print(y_test)
    #print(grid.predict(x_test))
    Predict = grid.predict(x_test)
    #Hstack = ['target','predict']

    #pd.DataFrame(columns=Hstack,data = np.hstack((np.mat(y_test).T,np.mat(Predict).T))).to_csv("E:\\pca Predict Accuracy"+str(score)+".csv")
    #print('精度为%s' % score)
    return score,y_test,Predict
def cal_accuracy(TP,TN,FP,FN):
    return (len(TP) + len(TN)) / (len(TP) + len(FN)+len(TN) + len(FP))
def cal_sensivity(TP, FN):
    return len(TP)/(len(TP) + len(FN))
def cal_spec(TN, FP):
    return len(TN)/(len(TN) + len(FP))
def cal_PPV(TP, FP):
    return len(TP)/(len(TP) + len(FP))
def cal_NPV(TN, FN):
    return len(TN)/(len(TN) + len(FN))
if __name__ == "__main__":

    total_result = []
    row_name = ['accuracy','sensivity', 'spec','ppv', 'npv']
    String1 = "F:/data/20191116data.csv"
    String2 = "F:/data/validation.csv"
    column_name = ['predict', 'test_truth']
    for Iter in range(5):
        total_result = []

        #score,y_test,pred = svm_c(*load_dataSet_1(j))
        score,y_test,pred = svm_c(*load_data(String1, String2, 44))
        target_y = np.array(y_test)
        pred_y = pred
        testlabel = y_test
        record_wrong = [r for r in range(target_y.size) if (pred_y == target_y).astype(int)[r] == 0]
        record_right = [r for r in range(target_y.size) if (pred_y == target_y).astype(int)[r] == 1]
        FP = [z for z in record_wrong if target_y[z] == 0]#0判断成1
        FN = [z for z in record_wrong if target_y[z] == 1]#1判断成0
        TP = [z for z in record_right if target_y[z] == 1]#1判断成1
        TN = [z for z in record_right if target_y[z] == 0]#0判断成0
        ALL_CAL_RESUTLT = [cal_accuracy(TP,TN,FP,FN), cal_sensivity(TP, FN),cal_spec(TN, FP),cal_PPV(TP, FP),cal_NPV(TN, FN)]

        total_result.append(ALL_CAL_RESUTLT[Iter])
        print(len(FP) + len(FN) + len(TP) + len(TN))
        print(len(target_y))
        new_result = []
        print(len(total_result))
        new_result.append(np.std(total_result))
        new_result.append(np.mean(total_result))
        for i in total_result:

            new_result.append(i)
        #print(new_result)
        #print(total_result)
        #print(np.mean(total_result))
        #print(np.std(total_result))
        print(len(ALL_CAL_RESUTLT))
        pd.DataFrame(data=np.hstack((np.mat(pred_y).T,np.mat(y_test).T)), columns=column_name).to_csv(
            "F:\\测试集预测结果.csv")
        pd.DataFrame(data=np.mat(ALL_CAL_RESUTLT),columns=row_name).to_csv(
            "F:\\测试集预测指标.csv")
