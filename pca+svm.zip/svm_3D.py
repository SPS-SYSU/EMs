import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.model_selection import KFold
import matplotlib.cm as cm
def data_process(String):
    global neural_num
    global pca_k
    global accuracy
    fr = open(String)
    df = pd.DataFrame(pd.read_csv(fr))
    for (i,j,z) in zip(df.iloc[:,0],df.iloc[:,1],df.iloc[:,2]):
        C.append(i)
        gamma.append(j)
        accuracy.append(z*100)
if __name__=='__main__':
    C = []
    gamma = []
    accuracy = []


    String = 'E:/svm/svm_score44.csv'
    data_process(String)
    print(accuracy)
    ax = plt.subplot(111, projection='3d')

    for index in range(np.shape(accuracy)[0]):
        '''if C[index]<0.7 or C[index]>1.0:
            continue
        if gamma[index]<0.1 or gamma[index]>0.3:
            continue'''
        if accuracy[index] <=82:
            continue
        if  accuracy[index] <=85:

            ax.scatter(C[index], gamma[index], accuracy[index], c='y')
        else:
            print(accuracy[index])
            ax.scatter(C[index], gamma[index], accuracy[index], s = 30,alpha=1,c='r')
    Z = np.zeros((100, 100))
    #for i in range(100):
    #    Z[i] = np.array([85.7] * 100)
    # surf = ax.plot_surface(X, Y, Z, alpha=0.01, color='y', linewidth=0.1, antialiased=False)
    #surf = ax.plot_surface(X, Y, Z, alpha=0.2, color='b', linewidth=0.1, antialiased=False)
    font1 = {'family': 'Times New Roman',
             'weight': 'normal',
             'size': 16,
             }
    ax.set_xlabel('C',font1)
    ax.set_ylabel("gamma",font1)
    ax.set_zlabel("Accuracy",font1)

    x_major_locator = plt.MultipleLocator(0.1)
    # 把x轴的刻度间隔设置为1，并存在变量里
    y_major_locator = plt.MultipleLocator(0.05)
    # 把y轴的刻度间隔设置为10，并存在变量里
    ax.xaxis.set_major_locator(x_major_locator)
    ax.yaxis.set_major_locator(y_major_locator)
    ax.set_xlim(0.4, 1.1)
    ax.set_ylim(0.2, 0.5)
    ax.set_zlim(82,85.2)
    plt.show()